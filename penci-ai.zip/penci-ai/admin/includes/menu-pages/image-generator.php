<h1><?php _e( 'AI Image generator', 'penci-ai' ); ?></h1>
<div id="penciai-image-generator" class="penciai-menu-page">
	<?php do_action( "penciai_image_generator_page" ); ?>
</div>